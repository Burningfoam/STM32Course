#ifndef __BSP_TEST_H__
#define __BSP_TEST_H__


void uart_proc(void);
void lcd_proc(void);




#endif

