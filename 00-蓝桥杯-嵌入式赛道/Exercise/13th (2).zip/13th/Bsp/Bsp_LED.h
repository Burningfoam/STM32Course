#ifndef __BSP_LED_H
#define __BSP_LED_H

extern unsigned char LED_State;  

extern void LED_Control(unsigned char ledstate);

#endif

