#ifndef __BSP_KEY_H
#define __BSP_KEY_H


extern unsigned char key_scan(void);

#endif


