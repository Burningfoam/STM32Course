#ifndef __BSP_LED_H
#define __BSP_LED_H


extern unsigned char led_state;

extern void led_control(unsigned char ledstate);

#endif

