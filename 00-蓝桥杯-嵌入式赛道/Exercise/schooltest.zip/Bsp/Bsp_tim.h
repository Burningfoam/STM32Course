#ifndef __BSP_TIM_H
#define __BSP_TIM_H


extern unsigned int in_rise;
extern unsigned int in_fall;
extern unsigned char in_duty;

extern unsigned int in_freq;

extern unsigned int out_freq;
extern unsigned char out_duty;




#endif






