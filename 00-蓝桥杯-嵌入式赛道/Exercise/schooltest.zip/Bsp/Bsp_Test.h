#ifndef __BSP_TEST_H
#define __BSP_TEST_H


//unsigned char lcd_state;

void led_proc(void);
void lcd_proc(void);
void rtc_test(void);
void rtc_proc(void);
void key_proc(void);
void uart_proc(void);
#endif

