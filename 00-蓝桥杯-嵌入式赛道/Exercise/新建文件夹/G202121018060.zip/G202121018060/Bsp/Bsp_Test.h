#ifndef __BSP_TEST_H
#define __BSP_TEST_H

extern unsigned char su;
extern void LCD_TestTask(void);
extern void KeyProcess(void);
extern void  Uart1_RX_Pro(void);


#endif
