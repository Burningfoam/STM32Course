#ifndef __BSP_ADC_H
#define __BSP_ADC_H

#include "main.h"
uint16_t getADC(void);

#endif 