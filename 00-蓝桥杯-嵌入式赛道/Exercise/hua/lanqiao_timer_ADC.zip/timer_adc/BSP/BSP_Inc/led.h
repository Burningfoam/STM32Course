#ifndef __LED_H
#define __LED_H

extern unsigned char led_state;

extern void Led_Control(unsigned char ledstate);

#endif 