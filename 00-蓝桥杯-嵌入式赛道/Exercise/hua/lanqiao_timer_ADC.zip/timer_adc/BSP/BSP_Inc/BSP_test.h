#ifndef __BSP_TEST_H
#define __BSP_TEST_H

void Key_Proc(void);
void LCD_Proc(void);
void ADC_Proc(void);
#endif 