#ifndef __KEY_H
#define __KEY_H

extern unsigned char key_scan(void);

#endif 