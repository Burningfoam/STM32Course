#ifndef __BSP_LED_H
#define __BSP_LED_H
extern unsigned char led_state;
void led_control(unsigned char led_value);

#endif
