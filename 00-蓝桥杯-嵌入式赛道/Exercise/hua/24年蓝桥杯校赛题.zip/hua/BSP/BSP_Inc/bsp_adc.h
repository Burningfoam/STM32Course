#ifndef __BSP_ADC_H
#define __BSP_ADC_H

float adc_read();
#endif
