#ifndef __BSP_UART_H
#define __BSP_UART_H
void uart_send(unsigned char*bufpt,unsigned char buflen);

#endif
