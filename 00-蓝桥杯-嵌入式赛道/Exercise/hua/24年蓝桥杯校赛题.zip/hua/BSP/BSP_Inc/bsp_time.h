#ifndef __BSP_time_H
#define __BSP_time_H


extern unsigned int in_frequent;
extern unsigned char in_dutyy;
extern unsigned int in_rise_time;
extern unsigned int in_fall_time;
#endif
