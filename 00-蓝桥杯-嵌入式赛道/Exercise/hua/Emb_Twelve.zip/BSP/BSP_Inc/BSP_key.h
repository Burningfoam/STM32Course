#ifndef __BSP_KEY_H
#define __BSP_KEY_H

unsigned char key_scan(void);

#endif