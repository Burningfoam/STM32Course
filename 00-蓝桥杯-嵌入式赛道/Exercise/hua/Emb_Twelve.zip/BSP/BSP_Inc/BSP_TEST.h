#ifndef __BSP_TEST_H
#define __BSP_TEST_H
void chewei_jiemian(void);
void Key_Proc(void);
void UART_Proc(void);
extern unsigned char Uart1_Tx_Buf[30];
extern unsigned char Usart1_RxData_Temp;
#endif