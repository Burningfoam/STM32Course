#ifndef __BSP_DAC_H
#define __BSP_DAC_H

extern float DAC1_CH1_Vol;
extern void DAC1_CH1_Set_Vol(float vol);


#endif
