#ifndef __BSP_MCP4017_H
#define __BSP_MCP4017_H

extern void iic_mcp4017_write(unsigned char val);
extern unsigned char iic_mcp4017_read(void);
#endif
