#ifndef __BSP_BUTTON_H
#define __BSP_BUTTON_H


#define B1_PRESS 1
#define B2_PRESS 2
#define B3_PRESS 3
#define B4_PRESS 4

extern unsigned char Key_scan(void);
#endif
